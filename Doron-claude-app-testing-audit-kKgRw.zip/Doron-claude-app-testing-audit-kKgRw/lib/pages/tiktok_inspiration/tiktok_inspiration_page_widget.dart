import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/services/firebase_data_service.dart';
import '/services/product_url_service.dart';
import '/components/connection_required_dialog.dart';
import '/components/aesthetic_buttons.dart';
import '/components/micro_interactions.dart' as micro;
import 'tiktok_inspiration_page_model.dart';
export 'tiktok_inspiration_page_model.dart';

/// Mode Inspiration - TikTok Style SIMPLIFIÉ
/// Swipe vertical entre produits, clic pour voir la fiche
class TikTokInspirationPageWidget extends StatefulWidget {
  const TikTokInspirationPageWidget({super.key});

  static String routeName = 'TikTokInspiration';
  static String routePath = '/inspiration';

  @override
  State<TikTokInspirationPageWidget> createState() => _TikTokInspirationPageWidgetState();
}

class _TikTokInspirationPageWidgetState extends State<TikTokInspirationPageWidget> {
  late TikTokInspirationPageModel _model;
  late PageController _pageController;

  static const Color _violetColor = Color(0xFF8A2BE2);
  static const Color _pinkColor = Color(0xFFEC4899);

  @override
  void initState() {
    super.initState();
    _model = TikTokInspirationPageModel();
    _pageController = PageController();

    // Charger les produits après le premier frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _model.loadProducts();
      }
    });

    // Écouter les changements du model
    _model.addListener(_onModelChanged);
  }

  void _onModelChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _model.removeListener(_onModelChanged);
    _pageController.dispose();
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    // État de chargement
    if (_model.isLoading) {
      return _buildLoadingState();
    }

    // État d'erreur
    if (_model.hasError) {
      return _buildErrorState();
    }

    // Liste vide
    if (_model.products.isEmpty) {
      return _buildEmptyState();
    }

    // Affichage des produits
    return _buildProductsView();
  }

  Widget _buildLoadingState() {
    return Container(
      color: Colors.black,
      child: Center(
        child: micro.FadeSlideIn(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              micro.PulseEffect(
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: const RadialGradient(
                      colors: [_violetColor, _pinkColor],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _violetColor.withOpacity(0.5),
                        blurRadius: 30,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.card_giftcard,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              micro.ShimmerEffect(
                child: Text(
                  'Chargement des inspirations...',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.red[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Erreur de chargement',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _model.errorMessage,
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: 200,
              child: PrimaryGradientButton(
                onPressed: () => _model.loadProducts(),
                text: 'Réessayer',
                icon: Icons.refresh,
                gradientColors: const [_violetColor, _pinkColor],
                height: 50,
              ),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Retour',
                style: GoogleFonts.poppins(color: Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.card_giftcard,
              size: 64,
              color: Colors.grey[600],
            ),
            const SizedBox(height: 16),
            Text(
              'Aucune inspiration disponible',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Retour',
                style: GoogleFonts.poppins(color: _violetColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductsView() {
    return Stack(
      children: [
        // PageView vertical pour swipe TikTok style
        PageView.builder(
          controller: _pageController,
          scrollDirection: Axis.vertical,
          itemCount: _model.products.length,
          onPageChanged: (index) {
            _model.setCurrentIndex(index);
            HapticFeedback.selectionClick();
          },
          itemBuilder: (context, index) {
            final product = _model.getProductAt(index);
            if (product == null) {
              return const SizedBox.shrink();
            }
            return _buildProductCard(product, index);
          },
        ),

        // Indicateur de progression (pas de ratio pour infinite scroll)
        Positioned(
          right: 12,
          top: 80,
          bottom: 80,
          child: _buildProgressIndicator(),
        ),

        // ✨ INFINITE SCROLL: Indicateur de chargement en bas
        if (_model.isLoadingMore)
          Positioned(
            bottom: 100,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Chargement...',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        // ✨ INFINITE SCROLL: Compteur de produits (pour debug/info)
        Positioned(
          top: 16,
          right: 60,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '${_model.currentIndex + 1} / ${_model.products.length}',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProgressIndicator() {
    final total = _model.products.length;
    final current = _model.currentIndex + 1;

    // Calculer le ratio de façon sécurisée
    double ratio = 0.0;
    if (total > 0) {
      ratio = current / total;
      // Sécurité: s'assurer que le ratio est valide
      if (ratio.isNaN || ratio.isInfinite) {
        ratio = 0.0;
      }
      ratio = ratio.clamp(0.0, 1.0);
    }

    return Container(
      width: 4,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(2),
      ),
      child: FractionallySizedBox(
        alignment: Alignment.topCenter,
        heightFactor: ratio,
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_pinkColor, _violetColor],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product, int index) {
    // Extraire les données de façon sécurisée
    final String name = product['name']?.toString() ?? 'Produit';
    final String brand = product['brand']?.toString() ?? '';
    final String image = product['image']?.toString() ?? '';
    final String url = product['url']?.toString() ?? '';
    final int price = product['price'] is int ? product['price'] : 0;
    final int match = product['match'] is int ? product['match'] : 85;

    final bool isLiked = _model.likedProductTitles.contains(name);

    return Stack(
      fit: StackFit.expand,
      children: [
        // Image en plein écran
        _buildProductImage(image),

        // Overlay gradient en bas
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  Colors.transparent,
                  Colors.black.withOpacity(0.8),
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        ),

        // Informations produit en bas
        Positioned(
          bottom: 0,
          left: 0,
          right: 70, // Laisser de la place pour le bouton coeur
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Badge marque avec effet néon
                if (brand.isNotEmpty)
                  NeonBadge(
                    text: brand.toUpperCase(),
                    color: _violetColor,
                  ),
                if (brand.isNotEmpty) const SizedBox(height: 8),

                // Nom du produit
                Text(
                  name,
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    height: 1.2,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),

                // Prix
                Text(
                  '${price}€',
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),

                // Bouton voir le produit avec effet gradient
                if (url.isNotEmpty)
                  PrimaryGradientButton(
                    onPressed: () => _openProductUrl(url),
                    text: 'Voir le produit',
                    icon: Icons.open_in_new,
                    gradientColors: const [_violetColor, _pinkColor],
                    height: 52,
                  ),
              ],
            ),
          ),
        ),

        // Bouton wishlist à droite
        Positioned(
          right: 16,
          bottom: 190,
          child: _buildWishlistButton(product),
        ),

        // Bouton coeur à droite
        Positioned(
          right: 16,
          bottom: 120,
          child: _buildLikeButton(product, isLiked),
        ),

        // Indicateur de swipe (seulement sur la première carte)
        if (index == 0)
          Positioned(
            bottom: 200,
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                children: [
                  Icon(
                    Icons.keyboard_arrow_up,
                    color: Colors.white.withOpacity(0.7),
                    size: 32,
                  ),
                  Text(
                    'Swipe infini ♾️',
                    style: GoogleFonts.poppins(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildProductImage(String imageUrl) {
    if (imageUrl.isEmpty) {
      return Container(
        color: Colors.grey[900],
        child: Center(
          child: Icon(
            Icons.image_not_supported,
            size: 64,
            color: Colors.grey[700],
          ),
        ),
      );
    }

    return CachedNetworkImage(
      imageUrl: imageUrl,
      fit: BoxFit.cover,
      width: double.infinity,
      height: double.infinity,
      placeholder: (context, url) => Container(
        color: Colors.grey[900],
        child: const Center(
          child: micro.ShimmerLoading(
            width: double.infinity,
            height: double.infinity,
            borderRadius: BorderRadius.zero,
          ),
        ),
      ),
      errorWidget: (context, url, error) => Container(
        color: Colors.grey[900],
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 48, color: Colors.grey[700]),
              const SizedBox(height: 8),
              Text(
                'Image non disponible',
                style: TextStyle(color: Colors.grey[600], fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLikeButton(Map<String, dynamic> product, bool isLiked) {
    return GlassmorphicButton(
      onPressed: () => _toggleFavorite(product),
      icon: isLiked ? Icons.favorite : Icons.favorite_border,
      color: isLiked ? Colors.red : _violetColor,
      size: 56,
      isActive: isLiked,
    );
  }

  Future<void> _openProductUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      print('❌ Erreur ouverture URL: $e');
    }
  }

  Future<void> _toggleFavorite(Map<String, dynamic> product) async {
    HapticFeedback.mediumImpact();

    final productName = product['name']?.toString() ?? '';
    if (productName.isEmpty) return;

    final isCurrentlyLiked = _model.likedProductTitles.contains(productName);

    // Mise à jour locale immédiate
    setState(() {
      if (isCurrentlyLiked) {
        _model.likedProductTitles.remove(productName);
      } else {
        _model.likedProductTitles.add(productName);
      }
    });

    // Vérifier l'authentification
    if (currentUserReference == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Connectez-vous pour sauvegarder vos favoris', style: GoogleFonts.poppins()),
          backgroundColor: Colors.orange[700],
        ),
      );
      return;
    }

    try {
      if (isCurrentlyLiked) {
        // Retirer des favoris
        final favorites = await queryFavouritesRecordOnce(
          queryBuilder: (q) => q
              .where('uid', isEqualTo: currentUserReference)
              .where('product.product_title', isEqualTo: productName),
        );
        for (var fav in favorites) {
          await fav.reference.delete();
        }
      } else {
        // Ajouter aux favoris
        await FavouritesRecord.collection.add(
          createFavouritesRecordData(
            uid: currentUserReference,
            platform: product['source']?.toString().toLowerCase() ?? 'amazon',
            timeStamp: DateTime.now(),
            product: ProductsStruct(
              productTitle: productName,
              productPrice: '${product['price'] ?? 0}€',
              productUrl: product['url']?.toString() ?? '',
              productPhoto: product['image']?.toString() ?? '',
              productStarRating: '',
              productOriginalPrice: '',
              productNumRatings: 0,
              platform: product['source']?.toString().toLowerCase() ?? 'amazon',
            ),
          ),
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Ajouté aux favoris', style: GoogleFonts.poppins()),
              backgroundColor: Colors.green[700],
              duration: const Duration(seconds: 1),
            ),
          );
        }
      }
    } catch (e) {
      print('❌ Erreur toggle favori: $e');
      // Revert local state on error
      setState(() {
        if (isCurrentlyLiked) {
          _model.likedProductTitles.add(productName);
        } else {
          _model.likedProductTitles.remove(productName);
        }
      });
    }
  }

  Widget _buildWishlistButton(Map<String, dynamic> product) {
    return GlassmorphicButton(
      onPressed: () => _showWishlistModal(product),
      icon: Icons.bookmark_border,
      color: _pinkColor,
      size: 56,
      isActive: false,
    );
  }

  /// Affiche le modal de sélection de wishlist
  Future<void> _showWishlistModal(Map<String, dynamic> product) async {
    // Vérifier si l'utilisateur est connecté
    final prefs = await SharedPreferences.getInstance();
    final isAnonymous = prefs.getBool('anonymous_mode') ?? false;

    if (isAnonymous || !loggedIn) {
      if (mounted) {
        await showConnectionRequiredDialog(
          context,
          title: 'Connexion requise',
          message: 'Crée ton compte pour organiser tes cadeaux en wishlists',
        );
      }
      return;
    }

    // Charger les wishlists existantes
    final wishlists = await FirebaseDataService.loadWishlists();

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Titre
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    const Icon(Icons.bookmark_border, color: _violetColor, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Ajouter à une wishlist',
                            style: GoogleFonts.poppins(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF111827),
                            ),
                          ),
                          Text(
                            product['name'] as String? ?? '',
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              color: const Color(0xFF6B7280),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const Divider(height: 1),

              // Liste des wishlists
              if (wishlists.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(40),
                  child: Column(
                    children: [
                      Icon(Icons.list_alt, size: 60, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text(
                        'Aucune wishlist',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[700],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Crée ta première wishlist ci-dessous',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                )
              else
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 300),
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: wishlists.length,
                    itemBuilder: (context, index) {
                      final wishlist = wishlists[index];
                      final giftCount = (wishlist['giftIds'] as List?)?.length ?? 0;

                      return ListTile(
                        leading: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: _violetColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.bookmark,
                            color: _violetColor,
                            size: 24,
                          ),
                        ),
                        title: Text(
                          wishlist['name'] as String? ?? 'Wishlist',
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF111827),
                          ),
                        ),
                        subtitle: Text(
                          '$giftCount cadeau${giftCount > 1 ? 's' : ''}',
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            color: const Color(0xFF6B7280),
                          ),
                        ),
                        trailing: const Icon(
                          Icons.add_circle,
                          color: _violetColor,
                          size: 28,
                        ),
                        onTap: () async {
                          Navigator.pop(context);
                          await _addToWishlist(product, wishlist['id'] as String);
                        },
                      );
                    },
                  ),
                ),

              const Divider(height: 1),

              // Bouton créer nouvelle wishlist
              Padding(
                padding: const EdgeInsets.all(20),
                child: PrimaryGradientButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await _createNewWishlist(product);
                  },
                  text: 'Créer une nouvelle wishlist',
                  icon: Icons.add,
                  gradientColors: const [_violetColor, _pinkColor],
                  height: 56,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Crée une nouvelle wishlist et y ajoute le produit
  Future<void> _createNewWishlist(Map<String, dynamic> product) async {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Nouvelle wishlist',
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              autofocus: true,
              decoration: InputDecoration(
                labelText: 'Nom de la wishlist',
                hintText: 'Ex: Anniversaire Maman',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: _violetColor, width: 2),
                ),
              ),
              style: GoogleFonts.poppins(),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(
                labelText: 'Description (optionnel)',
                hintText: 'Ex: Idées cadeaux pour ses 50 ans',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: _violetColor, width: 2),
                ),
              ),
              style: GoogleFonts.poppins(),
              maxLines: 2,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Annuler',
              style: GoogleFonts.poppins(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _violetColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Créer',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );

    if (result == true && nameController.text.isNotEmpty) {
      final wishlistId = await FirebaseDataService.createWishlist(
        name: nameController.text,
        description: descriptionController.text,
      );

      if (wishlistId != null) {
        await _addToWishlist(product, wishlistId);
      }
    }
  }

  /// Ajoute un produit à une wishlist
  Future<void> _addToWishlist(Map<String, dynamic> product, String wishlistId) async {
    try {
      // Créer d'abord le favori avec le produit
      final productTitle = product['name'] as String? ?? '';
      final productImage = product['image'] as String? ?? '';
      final productUrl = product['url'] ?? ProductUrlService.generateProductUrl(product);
      final brandOrSource = product['brand'] ?? product['source'] ?? 'Amazon';

      // Ajouter aux favoris Firebase avec wishlistId
      final docRef = await FavouritesRecord.collection.add(
        createFavouritesRecordData(
          uid: currentUserReference,
          platform: brandOrSource.toString().toLowerCase(),
          timeStamp: DateTime.now(),
          personId: null,
          product: ProductsStruct(
            productTitle: productTitle,
            productPrice: '${product['price'] ?? 0}€',
            productUrl: productUrl,
            productPhoto: productImage,
            productStarRating: '',
            productOriginalPrice: '',
            productNumRatings: 0,
            platform: brandOrSource.toString().toLowerCase(),
          ),
        ),
      );

      // Ajouter à la wishlist
      await FirebaseDataService.addToWishlist(wishlistId, docRef.id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.bookmark, color: Colors.white, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Ajouté à la wishlist !',
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            backgroundColor: const Color(0xFF10B981),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      print('❌ Erreur ajout wishlist: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Erreur lors de l\'ajout à la wishlist',
              style: GoogleFonts.poppins(),
            ),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    }
  }
}
