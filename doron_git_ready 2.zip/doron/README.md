# DORON

A new Flutter project.

## Getting Started

FlutterFlow projects are built to run on the Flutter _stable_ release.


## DORÕN Dev Agent Sync

- OpenAI key is loaded from `assets/environment_values/environment.json` and `.env` (OPENAI_API_KEY).
- To push to GitHub: `bash push_to_github.sh`
- In FlutterFlow: Settings → GitHub Sync → Refresh to see updates.
