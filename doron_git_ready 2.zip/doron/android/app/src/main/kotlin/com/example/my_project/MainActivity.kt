package com.mycompany.doron

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
